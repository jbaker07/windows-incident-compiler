EDR Incident Bundle
====================

Bundle ID: bundle-incident-001-20260111021101
Exported: 2026-01-11 02:11:01.116405 UTC
Format Version: 1.0.0
Hash Algorithm: sha256
Checksum: b0aeb8c23003f9c2902e6c3b54a983663acc0352c1e673d5c6092e9dc1c37fba
Redacted: true
Includes Replay: true
Includes Recompute: false

To import this bundle, use the Import Bundle feature in EDR Desktop.
